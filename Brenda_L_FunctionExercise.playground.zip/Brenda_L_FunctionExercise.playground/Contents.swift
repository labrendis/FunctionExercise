var a = 7
var b = 9

func plus(min: Int, max: Int) -> Int {
    let a = 7
    let b = 9
    return a + b
}
print(plus(min: a, max: b))
